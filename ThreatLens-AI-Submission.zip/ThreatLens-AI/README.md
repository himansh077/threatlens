# ThreatLens AI: MongoDB-Based Network Intrusion Detection & Traffic Analysis System

[![Python 3.13](https://img.shields.io/badge/python-3.13-blue.svg)](https://www.python.org/downloads/)
[![MongoDB 8.0](https://img.shields.io/badge/mongodb-8.0-green.svg)](https://www.mongodb.com/)
[![Tests Passing](https://img.shields.io/badge/pytest-35%20passed-brightgreen.svg)](tests/)
[![License: Academic](https://img.shields.io/badge/license-Academic%20Submission-lightgrey.svg)]()

> **Academic Submission**: B.Tech Degree Project Submission for **"Intelligent NoSQL Databases"**  
> **Course Code**: CSE494  
> **Author**: Faculty Academic Prototype  
> **Environment**: Windows 10/11, Python 3.10–3.13, Local MongoDB Community Server (`127.0.0.1:27017`)

---

## ⚡ 6-Command Windows Quick Start

Open **PowerShell** (or Command Prompt) in the project root directory:

```powershell
# 1. Create a dedicated virtual environment
python -m venv .venv

# 2. Activate virtual environment (includes PowerShell execution policy bypass)
Set-ExecutionPolicy -Scope Process Bypass; .\.venv\Scripts\Activate.ps1

# 3. Install verified dependencies
pip install -r requirements.txt

# 4. Initialize environment variables configuration
copy .env.example .env

# 5. Ensure local MongoDB Windows service is running
net start MongoDB

# 6. Execute complete end-to-end pipeline (generate, seed, train, evaluate, demo, test)
scripts\run_all.bat

# Launch the interactive Streamlit dashboard
streamlit run app.py
```

---

## 📋 Faculty & Syllabus Requirements Traceability

| Faculty Requirement | Implementation Module | Verification / Test | Report Section |
| :--- | :--- | :--- | :--- |
| **1. MongoDB with PyMongo** | `src/database.py`, `src/seed_database.py` | `tests/test_database.py` (6 tests) | Section 6 |
| **2. At Least One ML Model** | `src/train_classifier.py`, `src/train_regressor.py` | `tests/test_models.py` (4 tests) | Section 8 & 9 |
| **3. Classification Metrics** (Accuracy, Precision, Recall, F1) | `src/evaluate.py::evaluate_classifier` | `tests/test_models.py`, `outputs/metrics.json` | Section 10 |
| **3. Regression Metrics** (R², MAE) | `src/evaluate.py::evaluate_regressor` | `tests/test_models.py`, `outputs/metrics.json` | Section 10 |
| **4. Report Sections** (Intro, Objectives, Preprocessing, Evaluation, etc.) | `scripts/make_report.py` | `reports/project_report.docx` | Sections 1–14 |
| **5. Single Deliverable ZIP** | `scripts/make_zip.py` | `ThreatLens-AI-Submission.zip` | Section 14 |

---

## ⚠️ Mandatory Methodological Disclosures

### 1. Synthetic Demonstration Data Notice
This project uses **synthetic demonstration data** generated deterministically via NumPy (`seed=42`, 12,000 flows). It does **NOT** represent live enterprise packet captures or proprietary production network telemetry. It is engineered specifically to demonstrate intelligent NoSQL database modeling, complex aggregations, and resilient machine learning pipelines.

### 2. Flow Volume Regressor Interpretation
Flow byte counts (`total_bytes`) are generated based on service-specific packet size distributions multiplied by packet counts with log-normal variance. Therefore, a high $R^2$ score ($0.8954$) validates that the preprocessor column transformers, imputation, and Random Forest regressor function correctly end-to-end, rather than demonstrating empirical human-level payload prediction skill on unconstrained network links.

---

## 🏗️ System Architecture & Workflow

```
[Raw Network Flows]
        │
        ▼ (scripts/generate_data.py)
[data/traffic.csv] (12,000 rows, 80/20 Stratified Split)
        │
        ▼ (src/seed_database.py - Idempotent UpdateOne upsert)
[MongoDB: threatlens_db]
   ├── traffic_records (Flow telemetry, indexed on record_id, label, split)
   ├── predictions     (Inference snapshots linked via record_id)
   └── model_metrics   (Evaluation runs, confusion matrices, baselines)
        │
        ├──────────────────────────┐
        ▼                          ▼
[Classification Pipeline]   [Regression Pipeline]
(Predicts label: 0/1)        (Predicts total_bytes)
RandomForestClassifier      RandomForestRegressor
        │                          │
        └─────────────┬────────────┘
                      ▼
             [src/evaluate.py]
   ├── outputs/metrics.json
   ├── outputs/confusion_matrix.png
   ├── outputs/classifier_feature_importance.png
   └── outputs/regressor_actual_vs_predicted.png
                      │
        ┌─────────────┴────────────┐
        ▼                          ▼
[CLI: src/predict.py]     [Streamlit: app.py]
```

---

## 📊 Evaluation Summary (Test Set $N=2,400$)

| Task | Target | Model | Primary Metric | Baseline Comparison |
| :--- | :--- | :--- | :--- | :--- |
| **Intrusion Detection** | `label` (0/1) | Random Forest | **Accuracy: 96.42%**<br>**F1-Score: 0.9270**<br>Precision: 98.20%<br>Recall: 87.78% | Dummy (Most Frequent):<br>Accuracy: 74.08%<br>F1-Score: 0.0000 |
| **Volume Estimation** | `total_bytes` | Random Forest | **$R^2$: 0.8954**<br>**MAE: 42,383 Bytes** | Dummy (Mean Predictor):<br>$R^2$: -0.0017<br>MAE: 258,411 Bytes |

---

## 🛠️ CLI Usage Guide

Run all modules directly from the project root using standard Python module syntax:

### 1. Database Seeding & Interactive Demos
```powershell
# Idempotent bulk upsert into MongoDB
python -m src.seed_database

# 9-step MongoDB demonstration (CRUD, $lookup, Aggregations, Explain Plans)
python -m src.db_demo
```

### 2. Model Training
```powershell
# Train intrusion classifier from MongoDB
python -m src.train_classifier --source mongo

# Train flow volume regressor from MongoDB
python -m src.train_regressor --source mongo

# Offline training from local CSV (without MongoDB)
python -m src.train_classifier --source csv
python -m src.train_regressor --source csv
```

### 3. Model Evaluation
```powershell
python -m src.evaluate --source mongo
```

### 4. Prediction Engine
```powershell
# Predict by stored MongoDB record ID
python -m src.predict --record-id TL-000001

# Predict arbitrary flow from JSON input
python -m src.predict --input-json data/sample_input.json

# Batch predict on 5 random test split flows
python -m src.predict --sample 5

# Predict without persisting to MongoDB predictions collection
python -m src.predict --input-json data/sample_input.json --no-store
```

### 5. Automated Tests
```powershell
pytest -v
```

---

## 📂 Directory Structure

```
ThreatLens-AI/
├── README.md                           # Quick start and project documentation
├── requirements.txt                    # Pinned, tested dependencies
├── .env.example                        # Environment variables template
├── .gitignore                          # Excludes venvs, caches, temp files
├── pytest.ini                          # Pytest configuration (pythonpath = .)
├── app.py                              # 4-tab Streamlit web application
├── data/
│   ├── traffic.csv                     # 12,000 synthetic flow records
│   └── sample_input.json               # Sample input for inference testing
├── outputs/
│   ├── classifier.joblib               # Serialized intrusion classifier
│   ├── regressor.joblib                # Serialized volume regressor
│   ├── metrics.json                    # Programmatic evaluation metrics
│   ├── confusion_matrix.png            # Visual confusion matrix plot
│   ├── classifier_feature_importance.png# Feature importance bar chart
│   ├── regressor_actual_vs_predicted.png# Regression scatter plot
│   └── verification_log.txt            # Raw command logs for all phases
├── reports/
│   ├── project_report.docx             # Complete academic submission report
│   └── screenshots/                    # Real or placeholder UI screenshots
├── docs/
│   ├── MONGODB_SETUP_WINDOWS.md        # Windows MongoDB installation guide
│   ├── traceability.md                 # Detailed requirement-to-code mapping
│   ├── VERIFICATION_CHECKLIST.md       # Step-by-step verification log
│   └── VIVA_QA.md                      # Comprehensive viva defense questions
├── scripts/
│   ├── generate_data.py                # Synthetic dataset generator
│   ├── make_report.py                  # Report generator (.docx)
│   ├── run_all.bat                     # 7-stage automated execution script
│   └── make_zip.py                     # Clean submission ZIP packager
├── src/
│   ├── __init__.py
│   ├── config.py                       # Single source of truth (paths & features)
│   ├── database.py                     # MongoDB & PyMongo client, CRUD, aggregations
│   ├── data_loader.py                  # Validation and schema integrity loader
│   ├── preprocessing.py                # Preprocessor, splitting, leakage guards
│   ├── train_classifier.py             # Random Forest classifier training
│   ├── train_regressor.py              # Random Forest regressor training
│   ├── evaluate.py                     # Evaluation suite and plot generator
│   ├── seed_database.py                # Database population script
│   ├── predict.py                      # Multi-mode inference engine
│   └── db_demo.py                      # MongoDB query demonstration suite
└── tests/
    ├── conftest.py                     # Test fixtures and throwaway database
    ├── test_data_generation.py         # Data generator tests
    ├── test_data_loader.py             # Schema and range validation tests
    ├── test_preprocessing.py           # Stratification and leakage tests
    ├── test_models.py                  # Model training and reproducibility tests
    ├── test_database.py                # MongoDB CRUD and index tests
    └── test_predict.py                 # Single and batch inference tests
```
